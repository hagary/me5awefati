#pragma once

#include "SOIL.h"
#include <glut.h>	
#include <string>

GLuint loadTexture(std::string);

